LTC Bridge v1.2 — LTC (audio timecode) to MTC for Logic Pro, macOS 13+
https://github.com/jonpikereally/SPMTESync

INSTALL
1. Double-click "Install LTC Bridge.command".
   If macOS blocks it: right-click it, choose Open, then Open again.
2. Allow microphone access when asked — that's how it hears the LTC input.

USE
1. Pick the input device (e.g. your Dante interface or Dante Virtual
   Soundcard) and the channel carrying LTC.
2. The timecode turns green and says "Sending MTC" once it locks.
3. In Logic: Project Settings → Synchronization → Sync Mode: MTC, and
   switch on the Sync button. Logic sees the "LTC Bridge" MIDI port by itself.
"Test" generates LTC internally so you can check Logic without a source.

PRIVACY
Audio is only decoded, never recorded or sent anywhere. The only thing
LTC Bridge fetches from the internet is a small version file from the GitHub
repo above, to see whether an update exists.
