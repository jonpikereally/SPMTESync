#!/bin/bash
EXPECTED_VERSION=1.5
# LTC Bridge installer — copies the app to ~/Applications and launches it.
cd "$(dirname "$0")"
fail() {
  echo
  echo "Error $1: $2"
  echo "Look up this code on the LTC Bridge error list:"
  echo "  https://github.com/jonpikereally/SPMTESync/blob/main/ERRORS.md"
  echo "(You can also give that page to an AI assistant for help.)"
  exit 1
}
echo "Installing LTC Bridge…"
mkdir -p ~/Applications || fail LB-601 "Couldn't create ~/Applications."
if /usr/bin/pgrep -x LTCBridge >/dev/null; then
  fail LB-601 "Quit LTC Bridge before running the installer, then try again."
fi
STAGE_ROOT=$(mktemp -d ~/Applications/.LTCBridge-install-XXXXXX) \
  || fail LB-601 "Couldn't create a staging folder in ~/Applications."
trap 'rm -rf "$STAGE_ROOT"' EXIT
HELPER="LTC Bridge.app/Contents/Resources/InstallBundle.sh"
cp "$HELPER" "$STAGE_ROOT/InstallBundle.sh" \
  || fail LB-601 "The download is missing its installation helper."
HELPER="$STAGE_ROOT/InstallBundle.sh"
STAGED="$STAGE_ROOT/LTC Bridge.app"
/bin/bash "$HELPER" prepare "LTC Bridge.app" "$STAGED" com.jonpike.ltcbridge "$EXPECTED_VERSION" \
  || fail LB-602 "Couldn't validate or prepare the new version. Your installed copy was kept."
/bin/bash "$HELPER" swap 0 "$STAGED" ~/Applications/"LTC Bridge.app" \
  com.jonpike.ltcbridge ~/Library/"Application Support/LTC Bridge/update-failed.txt" "$EXPECTED_VERSION" \
  || fail LB-603 "Couldn't open the replacement. Any previous working copy was kept or restored."
echo
echo "Done! Allow LTC Bridge to use the microphone when macOS asks —"
echo "that's how it hears the LTC on your audio input."
