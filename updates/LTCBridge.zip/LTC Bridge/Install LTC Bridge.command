#!/bin/bash
# LTC Bridge installer — copies the app to ~/Applications and launches it.
cd "$(dirname "$0")"
fail() {
  echo
  echo "Error $1: $2"
  echo "Look up this code on the LTC Bridge error list:"
  echo "  https://github.com/jonpikereally/SPMTESync/blob/main/ERRORS.md"
  echo "(You can also give that page to an AI assistant for help.)"
  exit 1
}
echo "Installing LTC Bridge…"
mkdir -p ~/Applications || fail LB-601 "Couldn't create ~/Applications."
rm -rf ~/Applications/"LTC Bridge.app"
ditto --norsrc "LTC Bridge.app" ~/Applications/"LTC Bridge.app" \
  || fail LB-601 "Couldn't copy LTC Bridge into ~/Applications."
xattr -dr com.apple.quarantine ~/Applications/"LTC Bridge.app" 2>/dev/null
codesign --force --sign - ~/Applications/"LTC Bridge.app" 2>/dev/null \
  || fail LB-602 "Couldn't sign LTC Bridge for this Mac."
tccutil reset Microphone com.jonpike.ltcbridge >/dev/null 2>&1
open ~/Applications/"LTC Bridge.app" \
  || fail LB-603 "LTC Bridge was installed but couldn't be opened. Open it from ~/Applications yourself."
echo
echo "Done! Allow LTC Bridge to use the microphone when macOS asks —"
echo "that's how it hears the LTC on your audio input."
